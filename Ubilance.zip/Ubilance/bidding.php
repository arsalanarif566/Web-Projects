<?php
session_start();
if(!$_SESSION['email']){
	header('location:login.php?error = ');
}


$con = mysqli_connect('localhost', 'root', '', 'ubilance');

?>


<!DOCTYPE html>
<html>
<head>
<title>Bidding</title>

    <link rel="stylesheet" href="bidding.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body style="background-image:url(Images/qD0DjaI.jpg)">

<header>
<img src="Images/temp1.png" style="width:190px ; height:150px; padding:10px; margin-left:10px;" >
<a href="dashboard.php"><button class="home">Home</button></a>
<a href="profile.php"><button class="about">Profile</button></a>
<a href="#"><button class="gallery">Help</button></a>
<a href="logout.php"><button class="contact">Logout</button></a>

</header>

<!--.................-->
<div class="bid">

<?php
	$sql = "SELECT * FROM user_signup WHERE email = '".$_SESSION['email']."'";
	$res = mysqli_query($con, $sql) or die(mysqli_error($con));
	while($row = mysqli_fetch_assoc($res)){
		$dp = $row['profilePicture'];
		
	}
?>
<img src="<?php echo $dp ?>" style="width:200px; height:250px; float:right; padding:10px; margin-right:20px;">

 <?php
   
       $id = isset($_GET['id']) ;
	   $sql = "select * from jobs where ID = '20'";
	   $res = mysqli_query($con, $sql) or die(mysqli_error($con));
	   
	   if(mysqli_num_rows($res)){
		   while($row = mysqli_fetch_assoc($res)){
			   
         echo "<p style='color:#FFF; font-size:28px ; padding:10px; margin-top:0px;'>".$row['Job_Title']."</p>";  
         echo "<p style='color:#FFF; font-size:23px ; padding:10px;' >".$row['Job_Desc']."</p>"; 	   
	   }
	   }
           else{
		   echo "No Records Found";
	   }
   
   
   ?>

	   
</div>

<!--..................................-->
<form action="bidding.php" method="post">
<div class="place_bid" style="margin-top:40px; margin-left:1135px">
<input type="text" name = "text"  placeholder = "Place Bid Here" >
<input type="submit" name = "submit" value="Bid">

<?php   
if(isset($_POST['submit'])){

   $place_bid = $_POST['text'];
  
  $email = $_SESSION['email'];
  $query = "update user_signup set Bid= '$place_bid' where Email = '$email'" ;
   mysqli_query($con, $query) or die(mysqli_error($con));
   
	
}
?>

<?php
	$sql = "SELECT * FROM user_signup WHERE email = '".$_SESSION['email']."'";
	$res = mysqli_query($con, $sql) or die(mysqli_error($con));
	while($row = mysqli_fetch_assoc($res)){
		$bid = $row['Bid'];
		
	}
?>
<h5 style="color:#fff ;font-size:24px">You Placed Bid: <?php echo $bid;  ?></h5>
</div>
</form>

<!--..................................-->
<div class="container" style="margin-left:250px;">
  <h2 style="color:#FFF;">Bussiness</h2>
  <div class="progress" style="width:700px; margin-left:150px; margin-top:-35px;">
    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
      70%
    </div>
  </div>
<!--..........................-->  
<h2 style="color:#FFF;">Personal</h2>
  <div class="progress" style="width:700px; margin-left:150px; margin-top:-35px;">
    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:40%">
      40%
    </div>
  </div>
<!--.........................--> 
<h2 style="color:#FFF;">Finance</h2>
  <div class="progress" style="width:700px; margin-left:150px; margin-top:-35px;">
    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:50%">
      50%
    </div>
  </div>

</div>

<!--.........................-->

<div class="other_freelancers">
<h4 style="padding:10px; margin-left:30px; color:#FFF; font-size:24px; text-decoration:underline">Other Freelancers..</h4>
<?php

$query = "select profilePicture from user_signup ";
$run = mysqli_query($con, $query) or die (mysqli_error($con));

while($row = mysqli_fetch_assoc($run)){
	 $pp = $row ['profilePicture'];

?>
<img src="<?php  echo $pp  ?>" style="width:180px ; height:230px ; border-radius:10px; padding:15px; margin-left:20px;">

<?php }  ?>

<img src="Images/Testimonial.png" style="width:200px ; height:100px ; padding:15px; margin-left:-1010px; margin-top:300px; ">
<img src="Images/Testimonial.png" style="width:200px ; height:100px ; padding:15px;  margin-top:300px;">
<img src="Images/Testimonial.png" style="width:200px ; height:100px ; padding:15px;  margin-top:300px;">
<img src="Images/Testimonial.png" style="width:200px ; height:100px ; padding:15px;  margin-top:300px;">
<img src="Images/Testimonial.png" style="width:200px ; height:100px ; padding:15px;  margin-top:300px;">
<img src="Images/Testimonial.png" style="width:200px ; height:100px ; padding:15px;  margin-top:300px;">


</div>

</body>
</html>