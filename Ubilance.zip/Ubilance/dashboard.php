<?php
$con = mysqli_connect('localhost', 'root', '', 'ubilance');

session_start();
if(!$_SESSION['email']){
	header('location:login.php?error = ');
}

?>



<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>

   <link rel="stylesheet" href="dashboard.css">
   <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body>

<header>
<img src="Images/temp1.png" style="width:190px ; height:150px; padding:10px; margin-left:10px;" >
<a href="#"><button class="home">Home</button></a>
<a href="profile.php"><button class="about">Profile</button></a>
<a href="#"><button class="gallery">Help</button></a>
<a href="logout.php"><button class="contact">Logout</button></a>

</header>

   <div class="main_body">
   
    <div class="greetings">
   <p style="color:#FFF; font-size:20px; text-align:center;">Welcome:</p>
   <p style="color:#FFF; text-align:center"><?php  echo $_SESSION['email']; ?></p>
   </div>
   
   <div class="job_feed">
   <h2 style="font-size:26px; color:#009 ; padding:15px;">Job_Feed:</h2>
   <div class="div_1">
   <?php
   
   if(isset($_GET['cat'])){
	   $cat = urldecode($_GET['cat']);
	   $sql = "select * from jobs where category = '".$cat."'";
	   $res = mysqli_query($con, $sql) or die(mysqli_error($con));
	   
	   if(mysqli_num_rows($res)){
		   while($row = mysqli_fetch_assoc($res)){
			 $id = $row['ID']; 
			   
  echo "<div class='div_1' style='border-color:#000 ; margin-top:-18px;  ; width:910px; margin-left:-18px;'><h1 style='color:#009'>".$row['Job_Title']."</h1><p style='font-size:16px'>".$row['Job_Desc']."</p>  </div>";
  
  echo " <a href='bidding.php?id = '$id' style='float:right ; font-size:21px ; margin-top:-60px; margin-right:30px; 
			   color:#fff ; width:100px; text-align:center ; border-radius:5px ; background-color:#009'>BID</a> " ;
		  }
	   }else{
		   echo "No Records Found";
	   }
   }
   
   ?>
   </div>
   
   <!--...........................................-->
    
   </div>
   
   <div class="menu">
   
   <h3 style="color:#FFF; border-bottom:double 3px ; border-color:#FFF">Category:</h3>
  <a class="one" href="dashboard.php?cat=Web_Software Development"><input type="button" name="cate_1" class="cate_1" >Web & Software Development</a><br>
  <a class="one" href="dashboard.php?cat=IT_Networking"><input type="button" name="cate_2" class="cate_1">IT & Networking</a><br>
  <a class="one" href="dashboard.php?cat=Writing "><input type="button" name="cate_3" class="cate_1">Writing</a><br>
  <a class="one" href="dashboard.php?cat=Design_Creative"><input type="button" name="cate_4" class="cate_1">Design & Creative</a><br>
  <a class="one" href="dashboard.php?cat=Sales_Marketing"><input type="button" name="cate_5" class="cate_1">Sales & Marketing</a><br>
  <a class="one" href="dashboard.php?cat=Engineering_Architecture"><input type="button" name="cate_6" class="cate_1">Engineering & Architecture</a><br>
  <a class="one" href="dashboard.php?cat=Data Entry"><input type="button" name="cate_7" class="cate_1">Data Entry</a><br>
  <a class="one" href="dashboard.php?cat=Translation_Languages"><input type="button" name="cate_8" class="cate_1">Translation & Languages</a><br>
  <a class="one" href="dashboard.php?cat=Customer Service"><input type="button" name="cate_9" class="cate_1">Customer Service</a><br>
  <a class="one" href="dashboard.php?cat=Accounting_Consulting"><input type="button" name="cate_10" class="cate_1">Accounting & Consulting</a><br>
  
   
   </div>

   </div>
   
      
<div class="container">    
<footer>
<a href="https://www.facebook.com" target="_blank"><img class="facebook" src="Images/facebook-icon.png"></a>
<a href="https://twitter.com/" target="_blank"><img class="twitter" src="Images/twitter-icon.png"></a>
<a href="https://www.youtube.com/" target="_blank"><img class="linkedin" src="Images/social-linkedin-circle-128.png"></a>
<a href="https://www.skype.com/en/" target="_blank"><img class="google" src="Images/google_circle_color-128.png"></a>

<p class="one">© 2015 - 2016 Ubilance Global Inc.</p>
</footer>   
</div>

</body>
</html>
