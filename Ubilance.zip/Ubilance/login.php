<?php

session_start();

?>

<!DOCTYPE html>
<html>

<head>
   <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="login.css">
<link rel="icon" href="user_login.png">


</head>

<body>

<!--.......................-->
<form action="login.php" method="post">

<div class="container1">
   <!-- Modal -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content"  >
        <div class="modal-header" style="background-color:#3F9E9A">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sign_Up:</h4>
        </div>
        <div class="modal-body">
         <p id="name1">Enter your First Name:</p> <input type="text" name="name1" placeholder="First_Name" id="f_name">
         <p id="name2">Enter your Last Name:</p> <input type="text" name="name2" placeholder="Last_Name" id="l_name">
         <p id="country_n">Enter your Country Name:</p> <input type="text" name="country" placeholder="Country" id="country_name">
         <p id="username">Enter Your Email:</p><input type="email" name="email" placeholder="Email" id="username_two">
         <p id="password">Enter Your Password:</p><input type="password" name="password" placeholder="Password" id="password_three">
         
         
        </div>
        <!--Modal Footer-->
        <div class="modal-footer" >
          <input type="submit" class="btn btn-default" name="sign_up" value="Sign_Up">
        </div>
      </div>
      
    </div>
  </div>
  
</div>
</form>
<?php
mysql_connect("localhost","root","");
mysql_select_db("Ubilance");

if(isset($_POST['sign_up'])){
 
 echo $name_1 = $_POST['name1'];
 echo $name_2 = $_POST['name2'];
 echo $country = $_POST['country'];
 echo $email = $_POST['email'];
 echo $password = $_POST['password'];
 
 $query = "insert  into User_signup (First_Name,Last_Name,Country,Email,Password) values ('$name_1','$name_2','$country','$email','$password')";
 mysql_query($query);
}

?>

<form action="login.php" method="post">
<div class="img">
<img src="Images/images.png">
</div>

<div class="login">
<p>Login</p>
<p class="one">Enter your Username and Password to Log on</p>
<img class="user" src="Images/user_login.png">

<div class="textbox">
<i class="glyphicon glyphicon-user"></i><input type="text" name="email" placeholder="Username" class="username">
<span class="glyphicon glyphicon-lock"></span><input type="password" name="password" placeholder="Password" class="password">
<input type="submit" name="login" value="LOGIN" class="submit" >

<a class="sign_up" href="#" data-toggle="modal" data-target="#myModal1">Sign Up</a>

</form>

<?php
mysql_connect("localhost","root","");
mysql_select_db("ubilance");

if(isset($_POST['login'])){

$email =  $_SESSION['email'] = $_POST['email'];
$pass = $_POST['password'];

$query="select * from user_signup where Email= '$email' AND Password= '$pass' ";

$run=mysql_query($query);

if(mysql_num_rows($run)==1){
	
   echo " <script>window.open('dashboard.php?logged=You are Logged in Successfully!','_self')</script> ";
  
}else{
	echo "<script>alert('Username Or Password is Incorrect')</script>";
}
}
?>

</div>
</div>


</body>
</html>