<?php

session_start();
if(!$_SESSION['email']){
	header('location:login.php?error = ');
}

?>

<!DOCTYPE html >
<html >
<head>
<title>Profile</title>

 <link rel="stylesheet" href="profile.css">
 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
</head>

<body style="background-image:url(Images/qD0DjaI.jpg); height:600px;">


<header>
<img src="Images/temp1.png" style="width:190px ; height:150px; padding:10px; margin-left:10px;" >
<a href="dashboard.php"><button class="home">Home</button></a>
<a href="#"><button class="about">Profile</button></a>
<a href="#"><button class="gallery">Help</button></a>
<a href="logout.php"><button class="contact">Logout</button></a>

</header>

<div class="cover">
  
<?php
mysql_connect("localhost","root","");
mysql_select_db("Ubilance");
if(isset($_POST['upload'])){
	  $image_name = $_FILES['image']['name'];
	  $image_type = $_FILES['image']['type'];
  	  $image_size = $_FILES['image']['size'];
	  $image_tmp= $_FILES['image']['tmp_name'];
	   
	  $email=$_SESSION['email'];
	  
	  	move_uploaded_file($image_tmp, "$image_name");
	
	$query = "update user_signup set profilePicture = '$image_name' where Email = '$email' ";
	mysql_query($query);
	
	echo "<div class='cover' style= margin-left:70px;'><center><img src='$image_name' style='width:16% ; height:290px'></center></div>";
}

?>
<form method="post" action="profile.php" align= "center" enctype="multipart/form-data">
    <input type="file" name="image" style="margin-top:20px; float:right; margin-left:-190px;" ></br>
  <input type="submit" name="upload" value="Upload" style="float:right; width:90px; height:25px;">
  </form>
 
</div>

<!--...................................-->
<input type="button" name="edu" value="Add Description" style="padding:5px ; width:280px ; margin-left:135px;" data-toggle="modal" data-target="#myModal1">
<div class="edu">

<div class="content" style="width:750px;">
<h3 style="background-color:transparent; color:#FFF; margin-top:50px;">History has demonstrated that the most notable winners usually encountered heartbreaking obstacles before they triumphed. They won because they refused to become discouraged by their defeats.
</h3>
<p style="color:#FFF; margin-left:600px;">B.C Forbes</p>
<h3 style="background-color:transparent; color:#FFF;">I used to be a freelance journalist, so I had to write fast, but I always found writing nonfiction constraining. I like the freedom of fiction, where I get to invent everything, and tidy, conclusive endings are within my control. 
</h3>
<p style="color:#FFF; margin-left:600px;">Michelle Gagnon</p>
</div>

<img src="Images/freelancer.jpg" style="float:right ; margin-top:-320px;">
<h5 style="color:#FFF; text-align:center; margin-top:15px; padding:10px;"></h5>


<form action="profile.php?update=<?php echo $Email; ?>" method="post">

<div class="container1">
   <!-- Modal -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content"  >
        <div class="modal-header" style="background-color:#006">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="color:#FFF;">ADD DESCRIPTION:</h4>
         </div>
         
         <div class="modal-body">
         <h4 style="color:#006">SKILLS:</h4>
          <input type="text" name="skill_1" placeholder="Skill_1" id="f_name">
          <input type="text" name="skill_2" placeholder="Skill_2" id="l_name">
          <input type="text" name="skill_3" placeholder="Skill_3" id="country_name">
         <h4 style="color:#006">OBJECTIVE:</h4>
         <textarea name="obj" placeholder="Objective" id="obj"></textarea>
         <h4 style="color:#006">EDUCATION:</h4>
         <input type="text" name="degree" placeholder="Degree" id="l_name">
         <h4 style="color:#006">EXPERIENCE:</h4>
         <input type="text" name="exp" placeholder="Experience" id="f_name">
         
         
        </div>
        <!--Modal Footer-->
        <div class="modal-footer" >
         <input type="submit" class="btn btn-default" name="done" value="Done">
        </div>
      </div>
      
    </div>
  </div>
  
</div>
</form>

<?php
mysql_connect("localhost","root","");
mysql_select_db("Ubilance");

if(isset($_POST['done'])){
		
  $skill_1 = $_POST['skill_1'];
  $skill_2 = $_POST['skill_2'];
  $skill_3 = $_POST['skill_3'];
  $obj = $_POST['obj'];
  $edu = $_POST['degree'];
  $exp = $_POST['exp']; 
 
  $email=$_SESSION['email'];
  
 $query = "update user_signup set Skill_1 = '$skill_1' , Skill_2 = '$skill_2' ,Skill_3 = '$skill_3' , Objective = '$obj' , Education = '$edu' , 
 Experience = '$exp' where Email = '$email'";
 mysql_query($query);
}

?>

</div>

</div>

<!--..............................-->

<div class="retrieve">

<?php
mysql_connect("localhost","root","");
mysql_select_db("Ubilance");

 $email=$_SESSION['email'];
 $query = "select * from user_signup where Email = '$email'";
 $run = mysql_query($query);
 
 while($row = mysql_fetch_array($run)){
	 $skill_1 = $row['Skill_1'];
	 $skill_2 = $row['Skill_2'];
	 $skill_3 = $row['Skill_3'];
	 $obj = $row['Objective'];
	 $edu = $row['Education'];
	 $exp = $row['Experience'];
	 
	 ?>
     
    <div class="div_1"><p style="font-size:24px ; color:#FFF ; text-align:center ;padding:15px; border-bottom:double 2px ; border-color:#FFF;">Skills
</p><p style="color:#FFF; font:Verdana, Geneva, sans-serif; font-size:18px; padding:3px; text-align:center"><?php  echo $skill_1; ?></p><p style="color:#FFF; font:Verdana, Geneva, sans-serif; font-size:18px; padding:3px;text-align:center"> <?php  echo $skill_2; ?></p> <p style="color:#FFF; font:Verdana, Geneva, sans-serif; font-size:18px; padding:3px;text-align:center"><?php  echo $skill_3; ?></p></div>
<div class="div_2"><p style="font-size:24px ; color:#FFF ; text-align:center ; padding:15px;border-bottom:double 2px ; border-color:#FFF;">Objective</p>
<p style="color:#FFF; font:Verdana, Geneva, sans-serif; font-size:18px; padding:3px; text-align:center"><?php  echo "$obj"; ?></p></div>
<div class="div_3"><p style="font-size:24px ; color:#FFF ; text-align:center ; padding:15px;border-bottom:double 2px ; border-color:#FFF;">Education</p>
<p style="color:#FFF; font:Verdana, Geneva, sans-serif; font-size:18px; padding:3px; text-align:center"><?php  echo "$edu"; ?></p></div>
<div class="div_4"><p style="font-size:24px ; color:#FFF ; text-align:center ; padding:15px;border-bottom:double 2px ; border-color:#FFF;">Experience</p>
<p style="color:#FFF; font:Verdana, Geneva, sans-serif; font-size:18px; padding:3px; text-align:center"><?php  echo "$exp"; ?></p></div> 
 
 <?php } ?>



</div>

<!--....................................-->
</body>
</html>